# Candidate package

Read TASK.md, complete solve(csv_path) in solution.py, then run:

```bash
python -m pip install -r requirements.txt
python solution.py isotherms.csv answers.json
```

All data in this candidate package are synthetic. No solution, ground truth, instructor validation dataset or source-derived plot data is included.
